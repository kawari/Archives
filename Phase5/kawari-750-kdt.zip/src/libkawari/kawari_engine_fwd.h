class TKawariEngine;

