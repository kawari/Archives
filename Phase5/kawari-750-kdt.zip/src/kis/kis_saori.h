//---------------------------------------------------------------------------
//
// "�ؘa��" for ����ȊO�̉����ȊO�̉���
// KawariInlineScript -- SAORI --
//
//  2002.03.28  created
//  2002.03.29  add callsaorix
//
//---------------------------------------------------------------------------
// �֐��e�[�u���ւ̓o�^
#ifdef INLINE_SCRIPT_REGIST
INLINE_SCRIPT_REGIST(KIS_saoriregist);
INLINE_SCRIPT_REGIST(KIS_saorierase);
INLINE_SCRIPT_REGIST(KIS_callsaori);
INLINE_SCRIPT_REGIST(KIS_callsaorix);
#else
//---------------------------------------------------------------------------
#ifndef KIS_SAORI_H
#define KIS_SAORI_H
//---------------------------------------------------------------------------
#include "config.h"
//---------------------------------------------------------------------------
#include "kis/kis_base.h"
#include "misc/phttp.h"
//---------------------------------------------------------------------------
#include <vector>
#include <map>
using namespace std;
//---------------------------------------------------------------------------
class KIS_saoriregist : public TKisFunction_base {
public:

	// Init�Ŗ��O���̑��̏���ݒ肵�Ă�������
	virtual bool Init(void)
	{
		Name_="saoriregist";
		Format_="saoriregist dllname aliasname [ loadoption ]";
		Returnval_="(NULL)";
		Information_="register saorimodule";

		return(true);
	}

	// �C���^�[�v���^
	virtual string Function(const vector<string>& args);
};
//---------------------------------------------------------------------------
class KIS_saorierase : public TKisFunction_base {
public:

	// Init�Ŗ��O���̑��̏���ݒ肵�Ă�������
	virtual bool Init(void)
	{
		Name_="saorierase";
		Format_="saorierase aliasname";
		Returnval_="(NULL)";
		Information_="unregister saorimodule";

		return(true);
	}

	// �C���^�[�v���^
	virtual string Function(const vector<string>& args);
};
//---------------------------------------------------------------------------
class KIS_callsaori : public TKisFunction_base {
public:

	// Init�Ŗ��O���̑��̏���ݒ肵�Ă�������
	virtual bool Init(void)
	{
		Name_="callsaori";
		Format_="callsaori saorimodulename [param0] ...";
		Returnval_="(dll specific)";
		Information_="invoke request to SAORI/1.0 module";

		return(true);
	}

	// �C���^�[�v���^
	virtual string Function(const vector<string>& args);

protected:
	virtual bool CallSaori(
		const string& saoriname, const vector<string>& args,
		TPHMessage &response);
};
//---------------------------------------------------------------------------
class KIS_callsaorix : public KIS_callsaori {
public:

	// Init�Ŗ��O���̑��̏���ݒ肵�Ă�������
	virtual bool Init(void)
	{
		Name_="callsaorix";
		Format_="callsaorix stem saorimodulename [param0] ...";
		Returnval_="(dll specific)";
		Information_="invoke request to SAORI/1.0 module, and store values to stem";

		return(true);
	}

	// �C���^�[�v���^
	virtual string Function(const vector<string>& args);
};
//---------------------------------------------------------------------------
#endif
//---------------------------------------------------------------------------
#endif
